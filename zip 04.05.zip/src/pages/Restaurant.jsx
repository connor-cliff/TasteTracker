import React, { useRef, useEffect } from 'react';
import { CssBaseline, Card, Box, Grid, CardContent, Typography, Stack, Rating, Container, Table, TableRow, TableBody, TextField } from '@mui/material';
import { MyContainer, MyBold, MyTableCell } from '../styles.js'
import Footer from '../components/Footer.jsx';
import Header from '../components/Header.jsx';
import Review from '../components/Review.jsx';
import { Link } from "react-router-dom";
import theme from '../theme.jsx';

export default function Restaurant() {

  {/* this gets the height of the header and footer an subtracts it from the total height of the 
    viewport so the footer is positioned at the bottom of the page */
}
  const mainRef = useRef(null);
  const headerRef = useRef(null);

  useEffect(() => {
    const handleResize = () => {
      mainRef.current.style.minHeight = `calc(100vh - ${headerRef.current.clientHeight + document.querySelector('footer').clientHeight}px)`;
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <>
        <CssBaseline />
        <div ref={headerRef}>
        <Header  />
        </div>
        <main ref={mainRef}>
        <MyContainer maxWidth='sm' >
            <Box sx={{ ml: '18vw', mr: '18vw', mt: '2.5vw' }} > 
                <Typography gutterBottom variant='h2' sx={{ ml: '15px', mt: '10px' }}>
                    Khai Khai
                </Typography>
                <Grid container>
                    <Grid item>
                        <Stack spacing={1} sx={{ ml: 2, mt: 1, mb: 1 }}>
                           <Rating name="half-rating-read" defaultValue={4.5} precision={0.5} readOnly />
                        </Stack>
                    </Grid>
                    <Grid item>
                        <Typography sx={{ ml: '5px', mt: '10px' }}>
                            1 Rating
                        </Typography>
                    </Grid>
                </Grid>
                <Container>
                    <Typography gutterBottom>
                        <MyBold>Cuisine: </MyBold>Indian
                    </Typography>
                    <Typography gutterBottom>
                        <MyBold>Average main price: </MyBold>£12.48
                    </Typography>
                    <Typography gutterBottom>
                        <MyBold>Address: </MyBold>29 Queen St, Newcastle upon Tyne NE1 3UG
                    </Typography>
                    <Typography gutterBottom>
                        <MyBold>Approx walking time: </MyBold>6 minutes
                    </Typography>
                    <Typography gutterBottom>
                        <MyBold>Distance: </MyBold>57m
                    </Typography>
                    <Typography gutterBottom>
                        <MyBold>Menu: </MyBold><Link to='https://khaikhai.co.uk/' color='inherit'>khaikhai.co.uk</Link>
                    </Typography>
                    <Typography gutterBottom>
                        <MyBold>Phone: </MyBold>0191 261 4455
                    </Typography>
                    <Typography gutterBottom>
                        <MyBold>Opening times</MyBold> 
                    </Typography>
                    <Table sx={{ maxWidth: 300, maxHeight: 300 }}>
                        <TableBody>
                            <TableRow>
                                <MyTableCell>Monday</MyTableCell>
                                <MyTableCell>12:00 - 22:30</MyTableCell>
                            </TableRow>
                            <TableRow>
                                <MyTableCell>Tuesday</MyTableCell>
                                <MyTableCell>12:00 - 22:30</MyTableCell>
                            </TableRow>
                            <TableRow>
                                <MyTableCell>Wednesday</MyTableCell>
                                <MyTableCell>12:00 - 22:30</MyTableCell>
                            </TableRow>
                            <TableRow>
                                <MyTableCell>Thursday</MyTableCell>
                                <MyTableCell>12:00 - 22:30</MyTableCell>
                            </TableRow>
                            <TableRow>
                                <MyTableCell>Friday</MyTableCell>
                                <MyTableCell>12:00 - 23:00</MyTableCell>
                            </TableRow>
                            <TableRow>
                                <MyTableCell>Saturday</MyTableCell>
                                <MyTableCell>09:00 - 23:00</MyTableCell>
                            </TableRow>
                            <TableRow>
                              <MyTableCell>Sunday</MyTableCell>
                              <MyTableCell>09:00 - 23:00</MyTableCell>
                            </TableRow>
                        </TableBody>
                    </Table>
                    <Typography gutterBottom variant='h6' sx={{ mt: '20px' }}>
                        Ratings
                    </Typography>
                    <Card sx={{ boxShadow: '1px 1px 5px grey' }}>
                        <CardContent>
                            <div>
                               <Rating name="half-rating" precision={0.5} />
                            </div>
                           <div>
                             <TextField
                                id="outlined-multiline-flexible"
                                label="Leave a review"
                                multiline
                                maxRows={4}
                                sx={{ width: '100%' }}
                             />           
                           </div>
                        </CardContent>
                    </Card>
                    <Review />
                </Container>
            </Box>
        </MyContainer>
        </main>
        <Footer />
    </>
  )
};
