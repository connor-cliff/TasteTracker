import React from 'react'
import { Grid, CardMedia, Typography, Button, Container, Rating, Stack } from '@mui/material';
import { MyCard, MyCardGrid, MyCardContent, MyBold } from '../styles';
import { Link } from "react-router-dom";

import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

const cards = [1, 2, 3, 4, 5, 6]

function Listview() {

  return (
    <>
    
    <MyCardGrid maxWidth='md'>
            <Grid container spacing={4}>
                {cards.map((card) => (
                    <Grid item key={card} xs={12} sm={6} md={4}>
                        <MyCard>
                            <CardMedia 
                                component="img"
                                image="https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg"
                                alt="random"
                                title='Image title here'

                            /> 
                            <MyCardContent>
                                <Typography color='inherit' gutterBottom variant='h5' sx={{ ml: '15px', mt: '10px' }}>
                                    Khai Khai
                                </Typography>
                                <Stack spacing={1} sx={{ ml: 2, mt: 1, mb: 1 }}>
                                    <Rating name="half-rating-read" defaultValue={4.5} precision={0.5} readOnly />
                                </Stack>
                                <Container variant='h6' sx={{ mb: '20px' }}>
                                <Typography gutterBottom>
                                    <MyBold>Average main price: </MyBold>£12.48
                                </Typography>
                                <Button component={Link} to='/restaurant' variant='contained' size='small' color='primary' sx={{ mt: '7px' }}>See more details</Button>
                                </Container>
                            </MyCardContent>
                        </MyCard>
                </Grid>
                ))}
            </Grid>
        </MyCardGrid>
    </>
  )
}

export default Listview