import React from 'react'
import { Grid, CardMedia, Typography, Button, Container, Rating, Box, Stack } from '@mui/material';
import { MyCard, MyCardGrid, MyCardContent } from '../styles';

import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

const cards = [1, 2, 3, 4, 5, 6]

function Listview() {

  return (
    <>
    
    <MyCardGrid maxWidth='md'>
            <Grid container spacing={4}>
                {cards.map((card) => (
                    <Grid item key={card} xs={12} sm={6} md={6}>
                        <MyCard>
                            <CardMedia 
                                component="img"
                                image="https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg"
                                alt="random"
                                title='Image title here'

                            /> 
                            <MyCardContent >
                                    <Typography gutterBottom variant='h5' sx={{ ml: '15px', mt: '10px' }}>
                                        Chai House
                                    </Typography>
                                    <Stack spacing={1} sx={{ ml: 2, mt: 1, mb: 1 }}>
                                        <Rating name="half-rating-read" defaultValue={3.5} precision={0.5} readOnly />
                                    </Stack>
                                    <Container gutterBottom variant='h6'>
                                        <Typography>
                                            Average cost of main dish: £12.48
                                        </Typography>
                                        <Typography>
                                            Distance in metres: 57m
                                        </Typography>
                                        <Typography gutterBottom>
                                            Approximate walking time: 6 minutes
                                        </Typography>
                                        <div>
                                            <Grid container spacing={2}>
                                                <Grid item>
                                                    <Accordion sx={{ boxShadow: '1px 1px 5px grey', width: '18vw', mb: '30px' }}>
                                                        <AccordionSummary
                                                        expandIcon={<ExpandMoreIcon />}
                                                        aria-controls="panel1a-content"
                                                        id="panel1a-header"
                                                        >
                                                        <Typography>Opening times</Typography>
                                                        </AccordionSummary>
                                                        <AccordionDetails>
                                                        <Typography sx={{ whiteSpace: 'pre-line' }}>
                                                            Mon 12 - 10:30 pm{'\n'}
                                                            Tue 12 - 10:30 pm{'\n'}
                                                            Wed 12 - 10:30 pm{'\n'}
                                                            Thu 12 - 10:30 pm{'\n'}
                                                            Fri 12 - 11 pm{'\n'}
                                                            Sat 9 am - 11 pm{'\n'}
                                                            Sun 9 am - 11 pm
                                                        </Typography>
                                                        </AccordionDetails>
                                                    </Accordion>
                                                </Grid>
                                                <Grid item>
                                                    <Button variant='contained' size='small' color='primary' sx={{ mt: '7px' }}>Go to website</Button>
                                                </Grid>
                                            </Grid>
                                        </div>
                                    </Container>
                            </MyCardContent>
                        </MyCard>
                </Grid>
                ))}
            </Grid>
        </MyCardGrid>
    </>
  )
}

export default Listview