import React from 'react';
import { useState } from 'react';
import { Box, Button, Card, CardMedia, CssBaseline, Grid, Typography, Container } from '@mui/material';
import { MyContainer, MySlogan } from './styles';
import Dropdown from './components/Dropdown';
import Listview from './components/Listview';
import Mapview from './components/Mapview';
import Footer from './components/Footer';
import Header from './components/Header';

const cards = [1, 2, 3, 4, 5, 6]

const cuisines = ['American', 'Brazilian', 'Caribbean', 'Chinese', 'French', 'Greek', 'Indian', 'Italian', 'Japanese', 'Korean', 'Mediterranean', 'Mexican', 'Middle Eastern', 'Peruvian', 'Spanish', 'Thai', 'Vietnamese']

const App = () => {

    const [isMapView, setIsMapView] = useState(true);

    const toggleView = () => {
    setIsMapView((prevIsMapView) => !prevIsMapView);
    };
 

    return (
        <>
            <CssBaseline />
            <Header />
            <main>
                <div>
                    {// make myslogan on two lines by default
                    }
                    <MyContainer maxWidth='sm' >
                        <Card> 

                            <Box sx={{ width: '100px' }}>
                                <MySlogan align='center' sx={{ top: '25vh' }}>
                                    Find your next favorite restaurant
                                </MySlogan>
                            </Box>
                            <Box sx={{ position: 'relative' }}>
                                <CardMedia 
                                    component="img"
                                    sx={{ height: '50vh', filter: 'brightness(35%)' }}
                                    image="https://images.squarespace-cdn.com/content/v1/5a44e092e45a7c5289a2c962/1579452035230-HX17FJMPYEZC4L66AKDO/Food-photography-lacnashire-005.jpg"
                                    alt="random"
                                /> 
                            </Box>
                        </Card>

                        <Container sx={{ mt: '20px' }}>
                            <Typography variant='h1' align='left' color='textPrimary' >
                                Restaurants within a mile of you
                            </Typography>
                            <Typography variant='h5' align='left' color='textSecondary' paragraph>
                                Explore the map or customise the filter options to match your taste. 
                            </Typography>
                            <div>
                                <Grid container spacing={2} justifyContent='left'>
                                    <Grid item>
                                        <Typography variant='h5' color='textSecondary'>
                                            Filter by: 
                                        </Typography>
                                    </Grid>
                                    <Grid item>
                                        <Dropdown />
                                    </Grid>
                                    <Grid item>
                                        <Button variant='contained' color='primary' onClick={toggleView} >
                                        {isMapView ? "Switch to List View" : "Switch to Map View"}
                                        </Button>
                                    </Grid>
                                </Grid>
                                <Container>
                                  {isMapView ? <Mapview /> : <Listview />}
                                </Container>
                            </div>
                        </Container>       
                    </MyContainer>
                </div>
            </main>
            <Footer />
        </>
    );
}

export default App;