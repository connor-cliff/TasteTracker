import React from 'react'
//rfce
export default function NoPage() {
  return (
    <div>NoPage</div>
  )
}
